package stack;

import animation.Animation;
import animation.AnimationPool;
import animation.FlipAnimation;
import animation.FlipAnimation.FlipType;
import animation.MoveAnimation;
import game.Card;
import game.CardType;
import javafx.scene.canvas.GraphicsContext;
import util.Point;
import datastructures.MyQueue;

public class RestStack extends CardStack {
    private static final double HorizontalOffset = 200.0;
    private static final int NumShowingCards = 4;

    private Point position;
    private AnimationPool animationPool;
    private Card placeholderCard;
    private int topIndex;
    private MyQueue<Card> cards;

    public RestStack(AnimationPool animationPool, Point position) {
        this.position = position;
        this.animationPool = animationPool;
        this.cards = new MyQueue<>();
        CardType placeholderType = new CardType(CardType.Suit.Hearts, CardType.Color.Red, CardType.Value.Ace);
        this.placeholderCard = new Card(placeholderType);
        this.placeholderCard.setPosition(position);
        this.topIndex = -1;
    }

    @Override
    public void add(Card card) {
        this.cards.add(card);
        this.animationPool.add(new MoveAnimation(card, this.position, Animation.MoveTime));
    }

    private Card getTopCard() {
        if (this.topIndex < 0 || this.cards.isEmpty()) return null;
        return this.cards.get(this.topIndex);
    }

    private Hand pickFirstCard() {
        Hand result = new Hand();
        Card topCard = this.getTopCard();
        if (topCard != null) {
            result.add(topCard);
        }
        return result;
    }

    private void shiftCards() {
        this.topIndex++;
        if (this.topIndex >= this.cards.size()) {
            this.topIndex = -1;
            this.resetStack();
        } else {
            Card card = this.getTopCard();
            if (card != null) {
                card.flip();
                this.updateCardsPosition();
            }
        }
    }

    private void updateCardsPosition() {
        Card card = this.getTopCard();
        if (card != null) {
            this.animationPool.add(new FlipAnimation(card, FlipType.SHOW, Animation.FlipTime));
        }

        for (int i = 0; i < NumShowingCards; i++) {
            if (this.topIndex >= i) {
                Card currentCard = this.cards.get(this.topIndex - i);
                if (currentCard != null) {
                    this.animationPool.add(new MoveAnimation(
                            currentCard,
                            this.position.add(new Point(HorizontalOffset - CardStack.DefaultCardsMargin * i, 0)),
                            Animation.MoveTime));
                }
            }
        }
    }

    private void resetStack() {
        for (java.util.Iterator<Card> it = this.cards.iterator(); it.hasNext(); ) {
            Card card = it.next();
            this.animationPool.add(new MoveAnimation(card, this.position, Animation.MoveTime));
            if (card.isFlipped()) {
                card.flip();
                this.animationPool.add(new FlipAnimation(card, FlipType.HIDE, Animation.MoveTime));
            }
        }
    }

    @Override
    public Hand pick(Point p) {
        Hand result = new Hand();
        if (this.placeholderCard.isOver(p)) {
            this.shiftCards();
        } else if (this.topIndex >= 0) {
            Card topCard = this.getTopCard();
            if (topCard != null && topCard.isOver(p)) {
                result = pickFirstCard();
            }
        }
        return result;
    }

    @Override
    public boolean isOver(Point p) {
        if (this.placeholderCard.isOver(p)) return true;
        if (this.topIndex >= 0) {
            Card topCard = this.getTopCard();
            return topCard != null && topCard.isOver(p);
        }
        return false;
    }

    @Override
    public Point getTopPosition() {
        if (this.topIndex >= 0)
            return this.position.add(new Point(HorizontalOffset, 0));
        return (Point) this.position.clone();
    }

    @Override
    public void remove(Hand hand) {
        if (hand.size() == 1) {
            Card topCard = this.getTopCard();
            if (topCard != null && hand.bottom().equals(topCard)) {
                this.topIndex--;
                this.updateCardsPosition();
            }
        }
    }

    @Override
    public void drop(Hand hand) {
        for (Card card : hand.getCards()) {
            this.add(card);
        }
    }

    @Override
    public boolean isValidTop(Hand hand) {
        return false;
    }

    @Override
    public void draw(GraphicsContext ctx) {
        for (java.util.Iterator<Card> it = this.cards.iterator(); it.hasNext(); ) {
            it.next().draw(ctx);
        }
    }

    @Override
    public Card peek() {
        return this.cards.peek();
    }

    @Override
    public Card pop() {
        return this.cards.poll();
    }

    @Override
    public int size() {
        return this.cards.size();
    }
}
