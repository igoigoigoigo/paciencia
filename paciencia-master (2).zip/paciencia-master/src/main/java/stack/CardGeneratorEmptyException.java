package stack;

public class CardGeneratorEmptyException extends Exception {

    public CardGeneratorEmptyException(String message) {
        super(message);
    }
}
