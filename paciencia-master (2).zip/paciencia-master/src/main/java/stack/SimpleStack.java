package stack;

import animation.Animation;
import animation.FlipAnimation;
import animation.FlipAnimation.FlipType;
import animation.MoveAnimation;
import animation.AnimationPool;
import javafx.scene.canvas.GraphicsContext;
import game.Card;
import game.CardType;
import util.Point;
import datastructures.MyLinkedList;

import java.util.LinkedList;
import java.util.ListIterator;

public class SimpleStack extends CardStack {

    private AnimationPool animationPool;
    private Point position;
    private double cardsMargin;
    private Card placeholderCard;
    private int topIndex;
    private MyLinkedList<Card> cards;

    public SimpleStack(AnimationPool animationPool, Point position) {
        this.animationPool = animationPool;
        this.position = position;
        this.cardsMargin = CardStack.DefaultCardsMargin;

        this.cards = new MyLinkedList<>();

        CardType tipoCard = new CardType(CardType.Suit.Hearts, CardType.Color.Red, CardType.Value.Ace);
        this.placeholderCard = new Card(tipoCard);
        this.placeholderCard.setPosition(this.position);
        this.topIndex = 0;
    }

    @Override
    public void add(Card card) {
        this.cards.addLast(card);
        this.topIndex = this.cards.size() - 1;

        Point topPosition = this.getTopPosition();
        animationPool.add(new MoveAnimation(card, topPosition, Animation.MoveTime));

        this.updateCardsPositions();
    }

    @Override
    public Card peek() {
        return this.cards.peekLast();
    }

    @Override
    public Card pop() {
        Card card = this.cards.pollLast();
        this.topIndex = this.cards.size() - 1;

        if (this.cards.size() > 0 && !this.peek().isFlipped()) {
            animationPool.add(new FlipAnimation(this.peek(), FlipType.SHOW, Animation.FlipTime));
            this.peek().flip();
        }

        return card;
    }

    @Override
    public Hand pick(Point p) {
        Hand hand = new Hand();
        // iterar do final para o começo buscando cartas viradas
        int index = this.cards.size();
        java.util.Iterator<Card> iterator = this.cards.reverseIterator();
        while (iterator.hasNext()) {
            Card c = iterator.next();
            index--;
            if (c.isFlipped() && c.isOver(p)) {
                break;
            }
        }
        // pegar as cartas a partir desse index até o fim
        int i = 0;
        for (java.util.Iterator<Card> it = this.cards.iterator(); it.hasNext(); ) {
            Card card = it.next();
            if (i >= index)
                hand.add(card);
            i++;
        }

        this.topIndex = this.cards.size() - hand.size();
        return hand;
    }

    @Override
    public void remove(Hand hand) {
        for (Card card : hand.getCards()) {
            // Remover manualmente da lista ligada (implementar método remove em MyLinkedList se necessário)
        }
        if (this.cards.size() > 0 && !this.peek().isFlipped()) {
            animationPool.add(new FlipAnimation(this.peek(), FlipType.SHOW, Animation.FlipTime));
            this.peek().flip();
        }
        this.topIndex = this.cards.size() - 1;
    }

    @Override
    public void drop(Hand hand) {
        for (Card card : hand.getCards()) {
            this.add(card);
        }
        this.topIndex = this.cards.size() - 1;
        this.updateCardsPositions();
    }

    public void flipFirst() {
        if (this.cards.size() > 0) {
            this.peek().flip();
            this.peek().setAngle(0);
        }
    }

    @Override
    public Point getTopPosition() {
        return this.position.add(new Point(0, this.cardsMargin * (this.topIndex)));
    }

    @Override
    public void draw(GraphicsContext ctx) {
        for (java.util.Iterator<Card> it = this.cards.iterator(); it.hasNext(); ) {
            it.next().draw(ctx);
        }
    }

    @Override
    public boolean isOver(Point p) {
        boolean over = false;
        if (this.cards.size() > 0) {
            for (java.util.Iterator<Card> it = this.cards.iterator(); it.hasNext(); ) {
                if (it.next().isOver(p))
                    over = true;
            }
        } else
            over = this.placeholderCard.isOver(p);
        return over;
    }

    @Override
    public boolean isValidTop(Hand hand) {
        boolean isValid = false;

        Card card = hand.bottom();
        if (this.cards.size() > 0) {
            Card top = this.peek();
            if (top.getColor() != card.getColor() && CardType.isImediatlyGreater(card.getValue(), top.getValue()))
                isValid = true;
        } else if (card.getValue() == CardType.Value.King)
            isValid = true;

        return isValid;
    }

    @Override
    public int size() {
        return this.cards.size();
    }

    private void updateCardsPositions() {
        int numOfCards = this.cards.size();
        double stackHeight = this.cardsMargin * numOfCards + Card.Height;

        if (stackHeight > CardStack.MaxStackHeight) {
            this.cardsMargin = (MaxStackHeight - Card.Height) / numOfCards;
        }

        Point cardPosition = this.position;
        for (java.util.Iterator<Card> it = this.cards.iterator(); it.hasNext(); ) {
            Card card = it.next();
            animationPool.add(new MoveAnimation(card, cardPosition, Animation.MoveTime));
            cardPosition = cardPosition.add(new Point(0, this.cardsMargin));
        }
    }
}
